import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Star, Headphones, Calendar } from 'lucide-react';

export default function AdvancedFilters({ filters, onFiltersChange }) {
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 50 }, (_, i) => currentYear - i);

  return (
    <Card className="bg-white shadow-lg">
      <CardContent className="p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">بحث متقدم</h3>
        
        <div className="space-y-6">
          {/* Rating Filter */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-5 h-5 text-yellow-500" />
              <Label className="font-semibold">التقييم</Label>
            </div>
            <Select 
              value={filters.minRating} 
              onValueChange={(value) => onFiltersChange({ ...filters, minRating: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="جميع التقييمات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع التقييمات</SelectItem>
                <SelectItem value="4">4 نجوم فأكثر</SelectItem>
                <SelectItem value="3">3 نجوم فأكثر</SelectItem>
                <SelectItem value="2">2 نجوم فأكثر</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Audio Available */}
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Headphones className="w-5 h-5 text-orange-600" />
                <Label className="font-semibold">متوفر كصوتي فقط</Label>
              </div>
              <Switch
                checked={filters.audioOnly}
                onCheckedChange={(checked) => onFiltersChange({ ...filters, audioOnly: checked })}
              />
            </div>
          </div>

          {/* Publication Year */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-5 h-5 text-blue-600" />
              <Label className="font-semibold">سنة النشر</Label>
            </div>
            <Select 
              value={filters.publicationYear} 
              onValueChange={(value) => onFiltersChange({ ...filters, publicationYear: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="جميع السنوات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع السنوات</SelectItem>
                <SelectItem value="recent">آخر 5 سنوات</SelectItem>
                <SelectItem value="classic">كلاسيكيات (قبل 2000)</SelectItem>
                {yearOptions.slice(0, 20).map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Featured Books */}
          <div>
            <div className="flex items-center justify-between">
              <Label className="font-semibold">الكتب المميزة فقط</Label>
              <Switch
                checked={filters.featuredOnly}
                onCheckedChange={(checked) => onFiltersChange({ ...filters, featuredOnly: checked })}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}