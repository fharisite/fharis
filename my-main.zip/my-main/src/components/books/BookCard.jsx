import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Headphones, Star, Calendar, BookOpen, Edit } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function BookCard({ book }) {
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const isAdmin = user?.role === 'admin';
  return (
    <Card className="hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer h-full group relative overflow-hidden">
      <Link to={createPageUrl(`BookDetail?id=${book.id}`)} className="block">
        <CardContent className="p-0">
          {/* Cover Image */}
          <div className="relative overflow-hidden">
            <img
              src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
              alt={book.title}
              className="w-full aspect-[2/3] object-cover transition-transform duration-500 group-hover:scale-110"
            />
            
            {/* Overlay badges */}
            <div className="absolute top-2 right-2 left-2 flex justify-between items-start">
              {book.audio_available && (
                <Badge className="bg-orange-600 hover:bg-orange-700 text-white shadow-lg">
                  <Headphones className="w-3 h-3 ml-1" />
                  صوتي
                </Badge>
              )}
              {book.is_featured && (
                <Badge className="bg-yellow-500 hover:bg-yellow-600 text-white shadow-lg">
                  ⭐ مميز
                </Badge>
              )}
            </div>

            {/* Gradient overlay on hover */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>

          {/* Book Info */}
          <div className="p-4 space-y-2">
            <h3 className="font-bold text-base text-gray-900 line-clamp-2 leading-tight group-hover:text-orange-600 transition-colors">
              {book.title}
            </h3>
            
            <p className="text-sm text-gray-600 line-clamp-1">
              {book.author_name || book.author}
            </p>

            {/* Metadata row */}
            <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
              <div className="flex items-center gap-3">
                {book.rating && (
                  <div className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-yellow-500 text-yellow-500" />
                    <span className="font-semibold text-gray-900">{book.rating}</span>
                  </div>
                )}
                {book.pages && (
                  <div className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>{book.pages}</span>
                  </div>
                )}
              </div>
              {book.publication_year && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{book.publication_year}</span>
                </div>
              )}
            </div>

            {/* Category badge */}
            {book.category && (
              <Badge variant="outline" className="text-xs">
                {book.category}
              </Badge>
            )}
          </div>
        </CardContent>
      </Link>

      {/* Admin Edit Button */}
      {isAdmin && (
        <div className="absolute bottom-4 left-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
          <Link to={createPageUrl(`Admin?editBook=${book.id}`)} onClick={(e) => e.stopPropagation()}>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg">
              <Edit className="w-3 h-3 ml-1" />
              تحرير
            </Button>
          </Link>
        </div>
      )}
    </Card>
  );
}