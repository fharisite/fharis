import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Headphones, Star, Calendar, BookOpen, User } from 'lucide-react';

export default function BookListItem({ book }) {
  return (
    <Link to={createPageUrl(`BookDetail?id=${book.id}`)}>
      <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer group">
        <CardContent className="p-0">
          <div className="flex gap-4 p-4">
            {/* Cover Image */}
            <div className="flex-shrink-0 relative overflow-hidden rounded-md">
              <img
                src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                alt={book.title}
                className="w-24 h-36 sm:w-28 sm:h-42 object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>

            {/* Book Info */}
            <div className="flex-1 min-w-0 space-y-2">
              {/* Title and badges */}
              <div>
                <div className="flex items-start gap-2 mb-1 flex-wrap">
                  <h3 className="font-bold text-lg text-gray-900 group-hover:text-orange-600 transition-colors line-clamp-2">
                    {book.title}
                  </h3>
                  {book.is_featured && (
                    <Badge className="bg-yellow-500 hover:bg-yellow-600 text-white text-xs">
                      ⭐
                    </Badge>
                  )}
                  {book.audio_available && (
                    <Badge className="bg-orange-600 hover:bg-orange-700 text-white text-xs">
                      <Headphones className="w-3 h-3 ml-1" />
                      صوتي
                    </Badge>
                  )}
                </div>
                
                {/* Author */}
                <div className="flex items-center gap-1.5 text-gray-600">
                  <User className="w-4 h-4" />
                  <p className="text-sm">{book.author_name || book.author}</p>
                </div>
              </div>

              {/* Summary */}
              {book.summary && (
                <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">
                  {book.summary}
                </p>
              )}

              {/* Metadata */}
              <div className="flex items-center gap-4 flex-wrap text-sm">
                {book.rating && (
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                    <span className="font-semibold">{book.rating}</span>
                    {book.reviews_count > 0 && (
                      <span className="text-gray-500">({book.reviews_count})</span>
                    )}
                  </div>
                )}
                {book.pages && (
                  <div className="flex items-center gap-1 text-gray-600">
                    <BookOpen className="w-4 h-4" />
                    <span>{book.pages} صفحة</span>
                  </div>
                )}
                {book.publication_year && (
                  <div className="flex items-center gap-1 text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>{book.publication_year}</span>
                  </div>
                )}
              </div>

              {/* Category and Publisher */}
              <div className="flex items-center gap-2 flex-wrap">
                {book.category && (
                  <Badge variant="outline" className="text-xs">
                    {book.category}
                  </Badge>
                )}
                {book.publisher_name && (
                  <span className="text-xs text-gray-500">
                    {book.publisher_name}
                  </span>
                )}
              </div>

              {/* Tags */}
              {book.tags && book.tags.length > 0 && (
                <div className="flex items-center gap-1.5 flex-wrap">
                  {book.tags.slice(0, 3).map((tag, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {book.tags.length > 3 && (
                    <span className="text-xs text-gray-500">+{book.tags.length - 3}</span>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}