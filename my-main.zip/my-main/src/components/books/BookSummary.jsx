import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function BookSummary({ book }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGenerateSummary = async () => {
    setLoading(true);
    try {
      const response = await base44.functions.invoke('generateBookSummary', {
        bookTitle: book.title,
        bookAuthor: book.author_name,
        bookDescription: book.description
      });

      if (response.data.success) {
        setSummary(response.data.data);
      } else {
        toast.error('فشل في توليد الملخص');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('حدث خطأ في توليد الملخص');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {!summary ? (
        <Button
          onClick={handleGenerateSummary}
          disabled={loading}
          className="bg-gradient-to-l from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 ml-2 animate-spin" />
              جاري التوليد...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 ml-2" />
              توليد ملخص بالذكاء الاصطناعي
            </>
          )}
        </Button>
      ) : (
        <div className="space-y-6">
          {/* Summary */}
          <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-purple-900 mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                الملخص
              </h3>
              <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">
                {summary.summary}
              </p>
            </CardContent>
          </Card>

          {/* Quotes */}
          {summary.quotes && summary.quotes.length > 0 && (
            <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-amber-900 mb-4">اقتباسات</h3>
                <div className="space-y-4">
                  {summary.quotes.map((quote, index) => (
                    <div key={index} className="border-r-4 border-amber-400 pr-4 py-2">
                      <p className="text-gray-800 italic">"{quote}"</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Themes */}
          {summary.themes && summary.themes.length > 0 && (
            <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-blue-900 mb-4">الموضوعات الرئيسية</h3>
                <div className="flex flex-wrap gap-2">
                  {summary.themes.map((theme, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold"
                    >
                      {theme}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Button
            variant="outline"
            size="sm"
            onClick={handleGenerateSummary}
            disabled={loading}
          >
            إعادة التوليد
          </Button>
        </div>
      )}
    </div>
  );
}