import React from 'react';
import { Button } from '@/components/ui/button';
import { Share2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export default function SocialShare({ bookTitle, bookAuthor, bookUrl }) {
  const shareText = `${bookTitle} - ${bookAuthor}`;
  const encodedText = encodeURIComponent(shareText);
  const encodedUrl = encodeURIComponent(bookUrl);

  const shareOptions = [
    {
      name: 'تويتر/X',
      icon: '𝕏',
      url: `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`,
      color: 'hover:bg-black hover:text-white'
    },
    {
      name: 'فيسبوك',
      icon: 'f',
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      color: 'hover:bg-blue-600 hover:text-white'
    },
    {
      name: 'واتساب',
      icon: '📱',
      url: `https://wa.me/?text=${encodedText}%20${encodedUrl}`,
      color: 'hover:bg-green-600 hover:text-white'
    },
    {
      name: 'تليجرام',
      icon: '✈️',
      url: `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`,
      color: 'hover:bg-blue-500 hover:text-white'
    }
  ];

  const handleCopyLink = () => {
    navigator.clipboard.writeText(bookUrl);
    toast.success('تم نسخ الرابط');
  };

  const handleShare = (url) => {
    window.open(url, '_blank', 'width=600,height=400');
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Share2 className="w-4 h-4" />
          مشاركة
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" dir="rtl">
        {shareOptions.map((option) => (
          <DropdownMenuItem
            key={option.name}
            onClick={() => handleShare(option.url)}
            className={`cursor-pointer ${option.color}`}
          >
            <span className="ml-2">{option.icon}</span>
            {option.name}
          </DropdownMenuItem>
        ))}
        <DropdownMenuItem onClick={handleCopyLink} className="cursor-pointer">
          <span className="ml-2">🔗</span>
          نسخ الرابط
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}