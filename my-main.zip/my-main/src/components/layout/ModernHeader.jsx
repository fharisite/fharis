import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Menu, X, BookOpen, List, Users, Globe, Bell, Building } from 'lucide-react';
import GlobalSearch from '@/components/search/GlobalSearch';
import NotificationBell from '@/components/notifications/NotificationBell';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export default function ModernHeader() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const navLinks = [
    { name: 'الكتب', path: 'Books', icon: BookOpen },
    { name: 'المؤلفون', path: 'Authors', icon: Users },
    { name: 'الناشرون', path: 'Publishers', icon: Building },
    { name: 'قوائمي', path: 'MyLists', icon: List },
    { name: 'متابعاتي', path: 'MyFollowing', icon: Users },
    { name: 'القوائم العامة', path: 'PublicLists', icon: Globe },
  ];

  return (
    <header 
      className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50 shadow-sm"
      style={{
        paddingTop: 'env(safe-area-inset-top)',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Main Header */}
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link to={createPageUrl('Home')} className="flex-shrink-0">
            <div className="flex items-center gap-2 group">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-lg transform group-hover:scale-105 transition-transform duration-200">
                <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-2xl font-bold bg-gradient-to-l from-orange-600 to-amber-600 bg-clip-text text-transparent">
                  فهارس
                </h1>
                <p className="text-xs text-gray-500 -mt-1">مكتبتك الرقمية</p>
              </div>
            </div>
          </Link>

          {/* Desktop Search - Center */}
          <div className="hidden lg:flex flex-1 max-w-2xl mx-8">
            <GlobalSearch />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link key={link.path} to={createPageUrl(link.path)}>
                  <Button
                    variant="ghost"
                    className="gap-2 hover:bg-orange-50 hover:text-orange-600 transition-all"
                  >
                    <Icon className="w-4 h-4" />
                    {link.name}
                  </Button>
                </Link>
              );
            })}
            <NotificationBell />
            <Link to={createPageUrl('Settings')}>
              <Button
                variant="ghost"
                className="gap-2 hover:bg-orange-50 dark:hover:bg-gray-800 hover:text-orange-600 transition-all"
              >
                الإعدادات
              </Button>
            </Link>
            {user?.role === 'admin' && (
              <Link to={createPageUrl('Admin')}>
                <Button
                  size="sm"
                  className="mr-2 bg-gradient-to-l from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 shadow-md"
                >
                  لوحة التحكم
                </Button>
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-gray-700" />
            ) : (
              <Menu className="w-6 h-6 text-gray-700" />
            )}
          </button>
        </div>

        {/* Mobile Search */}
        <div className="lg:hidden pb-3">
          <GlobalSearch />
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-gray-200 bg-white">
          <div className="max-w-7xl mx-auto px-4 py-4 space-y-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.path}
                  to={createPageUrl(link.path)}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <div className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-orange-50 transition-colors">
                    <Icon className="w-5 h-5 text-orange-600" />
                    <span className="font-medium text-gray-900">{link.name}</span>
                  </div>
                </Link>
              );
            })}
            <Link
              to={createPageUrl('Admin')}
              onClick={() => setMobileMenuOpen(false)}
            >
              <div className="flex items-center gap-3 px-4 py-3 mt-2 rounded-lg bg-gradient-to-l from-orange-600 to-amber-600 text-white">
                <span className="font-medium">لوحة التحكم</span>
              </div>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}