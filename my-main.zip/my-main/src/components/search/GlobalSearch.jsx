import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, BookOpen, User, Building, X } from 'lucide-react';

export default function GlobalSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const searchRef = useRef(null);

  const { data: books = [] } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list('-created_date', 200),
  });

  const { data: authors = [] } = useQuery({
    queryKey: ['authors'],
    queryFn: () => base44.entities.Author.list(),
  });

  const { data: publishers = [] } = useQuery({
    queryKey: ['publishers'],
    queryFn: () => base44.entities.Publisher.list(),
  });

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchResults = React.useMemo(() => {
    if (!searchQuery.trim()) return { books: [], authors: [], publishers: [] };

    const query = searchQuery.trim().toLowerCase();
    const terms = query.split(/\s+/).filter(Boolean);

    const scoreText = (text, term, weight = 1) => {
      if (!text) return 0;
      const t = text.toLowerCase();
      if (t === term) return weight * 10;
      if (t.startsWith(term)) return weight * 6;
      if (t.includes(term)) return weight * 3;
      return 0;
    };

    const scoreBook = (book) => {
      let score = 0;
      for (const term of terms) {
        score += scoreText(book.title, term, 5);
        score += scoreText(book.author || book.author_name, term, 4);
        score += scoreText(book.author_name, term, 4);
        score += scoreText(book.publisher || book.publisher_name, term, 2);
        score += scoreText(book.category, term, 3);
        score += scoreText(book.summary, term, 2);
        score += scoreText(book.description, term, 1);
        score += scoreText(book.isbn, term, 4);
        if (book.genres?.some(g => scoreText(g, term, 3) > 0)) score += 3;
        if (book.tags?.some(t => scoreText(t, term, 2) > 0)) score += 2;
      }
      if (book.average_rating > 0) score += book.average_rating * 0.3;
      return score;
    };

    const filteredBooks = books
      .map(b => ({ ...b, _score: scoreBook(b) }))
      .filter(b => b._score > 0)
      .sort((a, b) => b._score - a._score)
      .slice(0, 6);

    const scoreAuthor = (a) => {
      let score = 0;
      for (const term of terms) {
        score += scoreText(a.name, term, 5);
        score += scoreText(a.nationality, term, 2);
        score += scoreText(a.bio, term, 1);
      }
      return score;
    };

    const filteredAuthors = authors
      .map(a => ({ ...a, _score: scoreAuthor(a) }))
      .filter(a => a._score > 0)
      .sort((a, b) => b._score - a._score)
      .slice(0, 3);

    const scorePublisher = (p) => {
      let score = 0;
      for (const term of terms) {
        score += scoreText(p.name, term, 5);
        score += scoreText(p.country, term, 2);
        score += scoreText(p.description, term, 1);
      }
      return score;
    };

    const filteredPublishers = publishers
      .map(p => ({ ...p, _score: scorePublisher(p) }))
      .filter(p => p._score > 0)
      .sort((a, b) => b._score - a._score)
      .slice(0, 3);

    return { books: filteredBooks, authors: filteredAuthors, publishers: filteredPublishers };
  }, [searchQuery, books, authors, publishers]);

  const hasResults = searchResults.books.length > 0 || 
                     searchResults.authors.length > 0 || 
                     searchResults.publishers.length > 0;

  const handleClear = () => {
    setSearchQuery('');
    setIsOpen(false);
  };

  return (
    <div ref={searchRef} className="relative flex-1 max-w-2xl">
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
        <Input
          type="text"
          placeholder="ابحث عن كتاب، مؤلف، ناشر، أو تصنيف..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className="pr-10 pl-10 text-right"
        />
        {searchQuery && (
          <button
            onClick={handleClear}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Results Dropdown */}
      {isOpen && searchQuery && (
        <Card className="absolute top-full mt-2 w-full z-50 shadow-2xl max-h-[70vh] overflow-y-auto">
          <CardContent className="p-4">
            {!hasResults ? (
              <div className="text-center py-8 text-gray-500">
                <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>لا توجد نتائج للبحث "{searchQuery}"</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Books */}
                {searchResults.books.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3 pb-2 border-b">
                      <BookOpen className="w-4 h-4 text-orange-600" />
                      <h3 className="font-semibold text-gray-900">الكتب ({searchResults.books.length})</h3>
                    </div>
                    <div className="space-y-2">
                      {searchResults.books.map((book) => (
                        <Link
                          key={book.id}
                          to={createPageUrl(`BookDetail?id=${book.id}`)}
                          onClick={handleClear}
                          className="block p-3 hover:bg-gray-50 rounded-lg transition-colors"
                        >
                          <div className="flex gap-3">
                            <img
                              src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                              alt={book.title}
                              className="w-12 h-16 object-cover rounded shadow-sm"
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-gray-900 truncate">{book.title}</h4>
                              <p className="text-sm text-gray-600 truncate">{book.author_name}</p>
                              <div className="flex gap-2 mt-1">
                                {book.category && (
                                  <Badge variant="outline" className="text-xs">
                                    {book.category}
                                  </Badge>
                                )}
                                {book.rating && (
                                  <Badge variant="outline" className="text-xs">
                                    ★ {book.rating}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                    {searchResults.books.length >= 5 && (
                      <Link
                        to={createPageUrl(`Books?search=${encodeURIComponent(searchQuery)}`)}
                        onClick={handleClear}
                        className="block mt-3 text-center text-sm text-orange-600 hover:text-orange-700 font-medium"
                      >
                        عرض جميع النتائج &lt;
                      </Link>
                    )}
                  </div>
                )}

                {/* Authors */}
                {searchResults.authors.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3 pb-2 border-b">
                      <User className="w-4 h-4 text-blue-600" />
                      <h3 className="font-semibold text-gray-900">المؤلفون ({searchResults.authors.length})</h3>
                    </div>
                    <div className="space-y-2">
                      {searchResults.authors.map((author) => (
                        <Link
                          key={author.id}
                          to={createPageUrl(`AuthorDetail?id=${author.id}`)}
                          onClick={handleClear}
                          className="block p-3 hover:bg-gray-50 rounded-lg transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            {author.photo ? (
                              <img
                                src={author.photo}
                                alt={author.name}
                                className="w-10 h-10 rounded-full object-cover"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-200 to-amber-200 flex items-center justify-center">
                                <User className="w-5 h-5 text-orange-600" />
                              </div>
                            )}
                            <div>
                              <h4 className="font-semibold text-gray-900">{author.name}</h4>
                              {author.nationality && (
                                <p className="text-sm text-gray-600">{author.nationality}</p>
                              )}
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {/* Publishers */}
                {searchResults.publishers.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3 pb-2 border-b">
                      <Building className="w-4 h-4 text-green-600" />
                      <h3 className="font-semibold text-gray-900">الناشرون ({searchResults.publishers.length})</h3>
                    </div>
                    <div className="space-y-2">
                      {searchResults.publishers.map((publisher) => (
                        <Link
                          key={publisher.id}
                          to={createPageUrl(`PublisherDetail?id=${publisher.id}`)}
                          onClick={handleClear}
                          className="block p-3 hover:bg-gray-50 rounded-lg transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            {publisher.logo ? (
                              <img
                                src={publisher.logo}
                                alt={publisher.name}
                                className="w-10 h-10 rounded object-contain bg-white"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded bg-gradient-to-br from-blue-200 to-indigo-200 flex items-center justify-center">
                                <Building className="w-5 h-5 text-blue-600" />
                              </div>
                            )}
                            <div>
                              <h4 className="font-semibold text-gray-900">{publisher.name}</h4>
                              {publisher.country && (
                                <p className="text-sm text-gray-600">{publisher.country}</p>
                              )}
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}