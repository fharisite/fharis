import React, { useState, useOptimistic } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Headphones, Star, BookmarkPlus, FileText, Hash, Tag, Calendar, BookOpen } from 'lucide-react';
import BookReviews from '../components/books/BookReviews';
import BookDiscussions from '../components/books/BookDiscussions';
import SocialShare from '../components/books/SocialShare';
import BookSummary from '../components/books/BookSummary';
import PurchaseLinks from '../components/books/PurchaseLinks';
import ModernHeader from '../components/layout/ModernHeader';
import BookRecommendations from '../components/books/BookRecommendations';
import SimilarBooks from '../components/books/SimilarBooks';
import { toast } from 'sonner';

export default function BookDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const bookId = urlParams.get('id');
  const [showAddToList, setShowAddToList] = useState(false);
  const [selectedListId, setSelectedListId] = useState('');

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: books = [] } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
  });

  const { data: authors = [] } = useQuery({
    queryKey: ['authors'],
    queryFn: () => base44.entities.Author.list(),
  });

  const { data: publishers = [] } = useQuery({
    queryKey: ['publishers'],
    queryFn: () => base44.entities.Publisher.list(),
  });

  const { data: myLists = [] } = useQuery({
    queryKey: ['myLists', user?.email],
    queryFn: () => base44.entities.BookList.filter({ owner_email: user?.email }),
    enabled: !!user,
  });

  const addToListMutation = useMutation({
    mutationFn: (data) => base44.entities.BookListItem.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['listItems'] });
      setShowAddToList(false);
      setSelectedListId('');
      toast.success('تمت إضافة الكتاب للقائمة');
    },
  });

  const book = books.find(b => b.id === bookId);
  const author = book?.author_id ? authors.find(a => a.id === book.author_id) : null;
  const publisher = book?.publisher_id ? publishers.find(p => p.id === book.publisher_id) : null;

  const handleAddToList = () => {
    if (!selectedListId) {
      toast.error('الرجاء اختيار قائمة');
      return;
    }
    addToListMutation.mutate({
      list_id: selectedListId,
      book_id: bookId,
    });
  };

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <p className="text-gray-600 mb-4">الكتاب غير موجود</p>
          <Link to={createPageUrl('Books')}>
            <Button>العودة للكتب</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-white dark:from-gray-900 dark:to-gray-800" dir="rtl">
      <ModernHeader />

      <div className="max-w-5xl mx-auto px-4 py-12">
        <Card className="overflow-hidden shadow-xl">
          <CardContent className="p-0">
            <div className="flex flex-col md:flex-row gap-8 p-8">
              {/* Book Cover */}
              <div className="flex-shrink-0">
                <img
                  src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                  alt={book.title}
                  className="w-64 h-96 object-cover rounded-lg shadow-2xl"
                />
              </div>

              {/* Book Details */}
              <div className="flex-1">
                <div className="mb-4">
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-4xl font-bold text-gray-900">{book.title}</h1>
                    {book.audio_available && (
                      <span className="flex items-center gap-1 text-orange-600 text-sm">
                        <Headphones className="w-5 h-5" />
                        🎧
                      </span>
                    )}
                  </div>
                  {book.author_id && author ? (
                    <Link to={createPageUrl(`AuthorDetail?id=${book.author_id}`)}>
                      <p className="text-xl text-gray-600 hover:text-orange-600 transition-colors cursor-pointer">
                        {book.author_name || author.name}
                      </p>
                    </Link>
                  ) : (
                    <p className="text-xl text-gray-600">{book.author_name || book.author}</p>
                  )}
                </div>

                {/* Rating */}
                {book.rating && (
                  <div className="flex items-center gap-2 mb-6">
                    <div className="flex items-center gap-1 bg-yellow-100 px-3 py-1 rounded-full">
                      <Star className="w-5 h-5 fill-yellow-500 text-yellow-500" />
                      <span className="font-bold text-lg">{book.rating}</span>
                    </div>
                  </div>
                )}

                {/* Category */}
                <div className="mb-6">
                  <span className="inline-block px-4 py-2 rounded-full text-sm font-semibold" style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)', color: '#75420e'}}>
                    {book.category}
                  </span>
                </div>

                {/* Book Info Grid */}
                <div className="mb-6 grid grid-cols-2 gap-4">
                  {book.isbn && (
                    <div className="flex items-start gap-2 bg-gray-50 p-3 rounded-lg">
                      <Hash className="w-5 h-5 text-gray-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500 mb-0.5">ISBN</p>
                        <p className="text-sm font-medium text-gray-900">{book.isbn}</p>
                      </div>
                    </div>
                  )}
                  {(book.publication_year || book.published_year) && (
                    <div className="flex items-start gap-2 bg-gray-50 p-3 rounded-lg">
                      <Calendar className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500 mb-0.5">سنة النشر</p>
                        <p className="text-sm font-medium text-gray-900">{book.publication_year || book.published_year}</p>
                      </div>
                    </div>
                  )}
                  {book.pages && (
                    <div className="flex items-start gap-2 bg-gray-50 p-3 rounded-lg">
                      <BookOpen className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500 mb-0.5">عدد الصفحات</p>
                        <p className="text-sm font-medium text-gray-900">{book.pages} صفحة</p>
                      </div>
                    </div>
                  )}
                  {book.language && (
                    <div className="flex items-start gap-2 bg-gray-50 p-3 rounded-lg">
                      <FileText className="w-5 h-5 text-purple-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500 mb-0.5">اللغة</p>
                        <p className="text-sm font-medium text-gray-900">{book.language}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Publisher */}
                {(book.publisher_id || book.publisher_name) && (
                  <div className="mb-6">
                    <h3 className="text-sm text-gray-500 mb-1">الناشر</h3>
                    {book.publisher_id && publisher ? (
                      <Link to={createPageUrl(`PublisherDetail?id=${book.publisher_id}`)}>
                        <p className="text-lg font-semibold text-gray-800 hover:text-orange-600 transition-colors cursor-pointer">
                          {book.publisher_name || publisher.name}
                        </p>
                      </Link>
                    ) : (
                      <p className="text-lg font-semibold text-gray-800">{book.publisher_name}</p>
                    )}
                  </div>
                )}

                {/* Tags */}
                {book.tags && book.tags.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm text-gray-500 mb-2 flex items-center gap-1">
                      <Tag className="w-4 h-4" />
                      الوسوم
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {book.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Summary */}
                {book.summary && (
                  <div className="mb-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">ملخص سريع</h3>
                    <p className="text-gray-700 leading-relaxed p-4 rounded-lg border-r-4 text-sm" style={{background: '#e9e5cd', borderColor: '#75420e'}}>
                      {book.summary}
                    </p>
                  </div>
                )}

                {/* Description */}
                {book.description && (
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-gray-900 mb-3">عن الكتاب</h2>
                    <p className="text-gray-700 leading-relaxed bg-gray-50 p-6 rounded-lg border-r-4" style={{borderColor: '#75420e'}}>
                      {book.description}
                    </p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-3 flex-wrap">
                  <Button className="text-lg px-8 py-6 text-white" style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}>
                    اقرأ الآن
                  </Button>
                  <SocialShare 
                    bookTitle={book.title}
                    bookAuthor={book.author_name}
                    bookUrl={window.location.href}
                  />
                  {user?.role === 'admin' ? (
                    <Link to={createPageUrl(`Admin?editBook=${bookId}`)}>
                      <Button className="text-lg px-8 py-6 bg-blue-600 hover:bg-blue-700">
                        تحرير
                      </Button>
                    </Link>
                  ) : (
                    <Link to={createPageUrl(`SuggestEdit?type=Book&id=${bookId}`)}>
                      <Button variant="outline" className="text-lg px-8 py-6">
                        اقترح تعديل
                      </Button>
                    </Link>
                  )}
                  {book.audio_available && (
                    <Button variant="outline" className="text-lg px-8 py-6">
                      <Headphones className="w-5 h-5 ml-2" />
                      استمع
                    </Button>
                  )}
                  <Dialog open={showAddToList} onOpenChange={setShowAddToList}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="text-lg px-8 py-6">
                        <BookmarkPlus className="w-5 h-5 ml-2" />
                        أضف لقائمة
                      </Button>
                    </DialogTrigger>
                    <DialogContent dir="rtl">
                      <DialogHeader>
                        <DialogTitle>إضافة لقائمة</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        {myLists.length === 0 ? (
                          <div className="text-center py-4">
                            <p className="text-gray-600 mb-4">ليس لديك قوائم بعد</p>
                            <Link to={createPageUrl('MyLists')}>
                              <Button>إنشاء قائمة جديدة</Button>
                            </Link>
                          </div>
                        ) : (
                          <>
                            <Select value={selectedListId} onValueChange={setSelectedListId}>
                              <SelectTrigger>
                                <SelectValue placeholder="اختر قائمة" />
                              </SelectTrigger>
                              <SelectContent>
                                {myLists.map((list) => (
                                  <SelectItem key={list.id} value={list.id}>
                                    {list.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <div className="flex gap-3 justify-end">
                              <Button variant="outline" onClick={() => setShowAddToList(false)}>
                                إلغاء
                              </Button>
                              <Button onClick={handleAddToList} className="text-white" style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}>
                                إضافة
                              </Button>
                            </div>
                          </>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Purchase Links Section */}
        <div className="mt-12">
          <PurchaseLinks purchaseLinks={book.purchase_links} />
        </div>

        {/* AI Summary Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">ملخص بالذكاء الاصطناعي</h2>
          <BookSummary book={book} />
        </div>

        {/* Reviews Section */}
        <div className="mt-12">
          <BookReviews bookId={bookId} />
        </div>

        {/* Discussions Section */}
        <div className="mt-12">
          <BookDiscussions bookId={bookId} />
        </div>

        {/* Similar Books Section */}
        <div className="mt-12">
          <SimilarBooks book={book} />
        </div>

        {/* Personalized Recommendations */}
        <div className="mt-12">
          <BookRecommendations />
        </div>
      </div>
    </div>
  );
}