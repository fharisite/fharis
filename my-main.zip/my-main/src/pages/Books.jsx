import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Search, ArrowRight, SlidersHorizontal, Grid3x3, List } from 'lucide-react';
import AdvancedSearch from '@/components/books/AdvancedSearch';
import BookCard from '@/components/books/BookCard';
import BookListItem from '@/components/books/BookListItem';

export default function Books() {
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [searchFilters, setSearchFilters] = useState({
    title: '',
    author: '',
    isbn: '',
    publisher: '',
    tags: '',
    category: 'all',
    year: 'all',
    minRating: 'all',
    audioOnly: false,
    featuredOnly: false
  });

  const { data: books = [], isLoading } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list('-created_date', 200),
  });

  const currentYear = new Date().getFullYear();

  const clearFilters = () => {
    setSearchFilters({
      title: '',
      author: '',
      isbn: '',
      publisher: '',
      tags: '',
      category: 'all',
      year: 'all',
      minRating: 'all',
      audioOnly: false,
      featuredOnly: false
    });
  };

  const filteredBooks = React.useMemo(() => {
    const scoreText = (text, term) => {
      if (!text) return 0;
      const t = text.toLowerCase();
      const q = term.toLowerCase();
      if (t === q) return 10;
      if (t.startsWith(q)) return 6;
      if (t.includes(q)) return 3;
      return 0;
    };

    const computeScore = (book) => {
      let score = 0;
      const terms = [
        searchFilters.title,
        searchFilters.author,
        searchFilters.tags,
      ].filter(Boolean).flatMap(s => s.trim().split(/\s+/));

      for (const term of terms) {
        if (searchFilters.title) {
          score += scoreText(book.title, term) * 5;
        }
        if (searchFilters.author) {
          score += scoreText(book.author || book.author_name, term) * 4;
          score += scoreText(book.author_name, term) * 4;
        }
        if (searchFilters.tags) {
          score += scoreText(book.summary, term) * 2;
          score += scoreText(book.description, term) * 1;
          score += scoreText(book.detailed_summary, term) * 1;
          if (book.tags?.some(t => scoreText(t, term) > 0)) score += 3;
          if (book.genres?.some(g => scoreText(g, term) > 0)) score += 2;
        }
      }

      if (searchFilters.isbn) score += scoreText(book.isbn, searchFilters.isbn) * 6;
      if (searchFilters.publisher) {
        score += scoreText(book.publisher || book.publisher_name, searchFilters.publisher) * 4;
      }

      if (score > 0 && book.average_rating > 0) score += book.average_rating * 0.4;

      return score;
    };

    const hasTextFilter = searchFilters.title || searchFilters.author || searchFilters.isbn ||
      searchFilters.publisher || searchFilters.tags;

    return books
      .map(book => {
        const matchesTitle = !searchFilters.title ||
          book.title?.toLowerCase().includes(searchFilters.title.toLowerCase());
        const matchesAuthor = !searchFilters.author ||
          [book.author, book.author_name].some(v => v?.toLowerCase().includes(searchFilters.author.toLowerCase()));
        const matchesISBN = !searchFilters.isbn ||
          book.isbn?.toLowerCase().includes(searchFilters.isbn.toLowerCase());
        const matchesPublisher = !searchFilters.publisher ||
          [book.publisher, book.publisher_name].some(v => v?.toLowerCase().includes(searchFilters.publisher.toLowerCase()));
        const matchesTags = !searchFilters.tags || (() => {
          const q = searchFilters.tags.toLowerCase();
          return (
            book.tags?.some(t => t.toLowerCase().includes(q)) ||
            book.genres?.some(g => g.toLowerCase().includes(q)) ||
            book.summary?.toLowerCase().includes(q) ||
            book.description?.toLowerCase().includes(q) ||
            book.detailed_summary?.toLowerCase().includes(q)
          );
        })();

        const matchesCategory = searchFilters.category === 'all' || book.category === searchFilters.category;

        let matchesYear = true;
        const pubYear = book.published_year || book.publication_year;
        if (searchFilters.year !== 'all' && pubYear) {
          if (searchFilters.year === 'recent') matchesYear = pubYear >= currentYear - 5;
          else if (searchFilters.year === '2020s') matchesYear = pubYear >= 2020 && pubYear < 2030;
          else if (searchFilters.year === '2010s') matchesYear = pubYear >= 2010 && pubYear < 2020;
          else if (searchFilters.year === '2000s') matchesYear = pubYear >= 2000 && pubYear < 2010;
          else if (searchFilters.year === 'classic') matchesYear = pubYear < 2000;
        }

        const matchesRating = searchFilters.minRating === 'all' ||
          ((book.average_rating || book.rating || 0) >= parseFloat(searchFilters.minRating));
        const matchesAudio = !searchFilters.audioOnly || book.audio_available;
        const matchesFeatured = !searchFilters.featuredOnly || book.is_featured;

        const passes = matchesTitle && matchesAuthor && matchesISBN && matchesPublisher &&
          matchesTags && matchesCategory && matchesYear && matchesRating && matchesAudio && matchesFeatured;

        return { ...book, _score: passes ? (hasTextFilter ? computeScore(book) : 1) : -1 };
      })
      .filter(b => b._score >= 0)
      .sort((a, b) => b._score - a._score);
  }, [books, searchFilters, currentYear]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <Link to={createPageUrl('Home')}>
              <div className="text-3xl font-bold bg-gradient-to-l from-orange-600 to-amber-600 bg-clip-text text-transparent cursor-pointer">
                فهارس
              </div>
            </Link>
            <div className="flex items-center gap-3">
              <span className="text-gray-600 font-semibold">البحث في الكتب</span>
              <Link to={createPageUrl('Home')}>
                <Button variant="ghost">
                  <ArrowRight className="w-4 h-4 ml-2" />
                  العودة
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar - Advanced Search */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-4">
              <Button
                variant={showAdvancedSearch ? "default" : "outline"}
                className={`w-full justify-start gap-2 ${showAdvancedSearch ? 'bg-gradient-to-l from-orange-600 to-amber-600' : ''}`}
                onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
              >
                <SlidersHorizontal className="w-4 h-4" />
                {showAdvancedSearch ? 'إخفاء البحث المتقدم' : 'البحث المتقدم'}
              </Button>

              {showAdvancedSearch && (
                <AdvancedSearch 
                  filters={searchFilters} 
                  onFiltersChange={setSearchFilters}
                  onClear={clearFilters}
                />
              )}
            </div>
          </div>

          {/* Books Grid */}
          <div className="lg:col-span-3">
            {/* Results Count and Active Filters */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
                <h2 className="text-2xl font-bold text-gray-900">
                  {filteredBooks.length} كتاب
                </h2>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                    <Button
                      variant={viewMode === 'grid' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('grid')}
                      className={viewMode === 'grid' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                    >
                      <Grid3x3 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={viewMode === 'list' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('list')}
                      className={viewMode === 'list' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                    >
                      <List className="w-4 h-4" />
                    </Button>
                  </div>
                {(searchFilters.title || searchFilters.author || searchFilters.isbn || searchFilters.publisher || 
                  searchFilters.tags || searchFilters.category !== 'all' || searchFilters.year !== 'all' || 
                  searchFilters.minRating !== 'all' || searchFilters.audioOnly || searchFilters.featuredOnly) && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    مسح الفلاتر
                  </Button>
                )}
                </div>
                </div>

              {/* Active Filters Display */}
              <div className="flex flex-wrap gap-2">
                {searchFilters.title && (
                  <span className="text-xs bg-orange-100 text-orange-700 px-3 py-1 rounded-full">
                    العنوان: {searchFilters.title}
                  </span>
                )}
                {searchFilters.author && (
                  <span className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                    المؤلف: {searchFilters.author}
                  </span>
                )}
                {searchFilters.isbn && (
                  <span className="text-xs bg-teal-100 text-teal-700 px-3 py-1 rounded-full">
                    ISBN: {searchFilters.isbn}
                  </span>
                )}
                {searchFilters.publisher && (
                  <span className="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full">
                    الناشر: {searchFilters.publisher}
                  </span>
                )}
                {searchFilters.tags && (
                  <span className="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
                    الوسوم: {searchFilters.tags}
                  </span>
                )}
                {searchFilters.category !== 'all' && (
                  <span className="text-xs bg-amber-100 text-amber-700 px-3 py-1 rounded-full">
                    {searchFilters.category}
                  </span>
                )}
                {searchFilters.minRating !== 'all' && (
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full">
                    {searchFilters.minRating}★ وأعلى
                  </span>
                )}
                {searchFilters.audioOnly && (
                  <span className="text-xs bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full">
                    🎧 صوتي
                  </span>
                )}
                {searchFilters.featuredOnly && (
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full">
                    ⭐ مميز
                  </span>
                )}
              </div>
            </div>

            {isLoading ? (
              <div className={viewMode === 'grid' ? 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6' : 'space-y-4'}>
                {[...Array(viewMode === 'grid' ? 12 : 6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    {viewMode === 'grid' ? (
                      <>
                        <div className="w-full aspect-[2/3] bg-gray-200 rounded-lg mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </>
                    ) : (
                      <div className="flex gap-4 p-4 bg-white rounded-lg">
                        <div className="w-24 h-36 bg-gray-200 rounded"></div>
                        <div className="flex-1 space-y-3">
                          <div className="h-5 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                          <div className="h-3 bg-gray-200 rounded"></div>
                          <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : filteredBooks.length === 0 ? (
              <div className="text-center py-20">
                <Search className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 text-xl mb-2">لم يتم العثور على كتب</p>
                <p className="text-gray-400">جرب تغيير معايير البحث</p>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredBooks.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredBooks.map((book) => (
                  <BookListItem key={book.id} book={book} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}