import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Headphones } from 'lucide-react';
import ModernHeader from '@/components/layout/ModernHeader';
import BookRecommendations from '@/components/books/BookRecommendations';

export default function Home() {

  const { data: books = [], isLoading } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list('-created_date', 50),
  });

  const featuredBook = books.find(book => book.is_featured);
  const categories = [
    'روايات وقصص',
    'كتب الأدب',
    'كتب تاريخية',
    'كتب دينية',
    'كتب سياسية',
    'كتب علمية',
    'مال وأعمال',
    'علم النفس وتطوير الذات',
    'السيرة الذاتية والمذكرات'
  ];

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)'}} dir="rtl">
      <ModernHeader />

      {/* Hero Section */}
      <section style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)'}} className="py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-6 sm:mb-8">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">الكتب</h1>
            <p className="text-base sm:text-lg md:text-xl text-gray-700 italic mb-3 sm:mb-4 px-4">
              "قرأت كتاباً في يوم من الأيام؛ فتغيرت حياتي كلها." - أورهان باموق
            </p>
            <p className="text-sm sm:text-base text-gray-600 max-w-3xl mx-auto leading-relaxed px-4">
              أهلاً بك في مكتبة فهارس! ابدأ رحلتك في عالم قراءة الكتب الإلكترونية واستمتع بقراءة آلاف الكتب والروايات العربية والعالمية المترجمة على فهارس.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Featured Book */}
        {featuredBook && (
          <section className="mb-12 sm:mb-16">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">كتاب اليوم</h2>
            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <CardContent className="p-0">
                <div className="flex flex-col md:flex-row gap-4 sm:gap-6 p-4 sm:p-6">
                  <div className="flex-shrink-0 mx-auto md:mx-0">
                    <img
                      src={featuredBook.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                      alt={featuredBook.title}
                      className="w-32 h-48 sm:w-40 sm:h-60 md:w-48 md:h-72 object-cover rounded-lg shadow-lg"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                      <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900">{featuredBook.title}</h3>
                      {featuredBook.audio_available && (
                        <span className="text-orange-600 flex items-center gap-1 text-xs sm:text-sm">
                          <Headphones className="w-3 h-3 sm:w-4 sm:h-4" />
                          اسمع على فهارس 🎧
                        </span>
                      )}
                    </div>
                    <p className="text-sm sm:text-base text-gray-600 mb-3 sm:mb-4">{featuredBook.author_name}</p>
                    {featuredBook.rating && (
                      <div className="flex items-center gap-2 mb-3 sm:mb-4">
                        <span className="text-yellow-500">★</span>
                        <span className="font-semibold text-sm sm:text-base">{featuredBook.rating}</span>
                      </div>
                    )}
                    <p className="text-sm sm:text-base text-gray-700 leading-relaxed bg-gray-50 p-3 sm:p-4 rounded-lg border-r-4 border-orange-500">
                      {featuredBook.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Recommendations Section */}
        <BookRecommendations />

        {/* Categories */}
        <section className="mb-12 sm:mb-16">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">التصنيفات</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4">
            {categories.map((category) => (
              <Link key={category} to={createPageUrl(`Books?category=${encodeURIComponent(category)}`)}>
                <Card className="hover:shadow-lg transition-all hover:scale-105 cursor-pointer" style={{background: 'linear-gradient(to bottom right, #ffffff, #e9e5cd)'}}>
                  <CardContent className="p-4 sm:p-6 text-center">
                    <h3 className="text-sm sm:text-base lg:text-lg font-semibold text-gray-900">{category}</h3>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Latest Books */}
        <section>
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">أحدث الإصدارات</h2>
            <Link to={createPageUrl('Books')}>
              <Button variant="outline" size="sm">المزيد &lt;</Button>
            </Link>
          </div>
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 md:gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="w-full aspect-[2/3] bg-gray-200 rounded-lg mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 md:gap-6">
              {books.slice(0, 12).map((book) => (
                <Link key={book.id} to={createPageUrl(`BookDetail?id=${book.id}`)}>
                  <Card className="hover:shadow-xl transition-all hover:scale-105 cursor-pointer h-full">
                    <CardContent className="p-0">
                      <img
                        src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                        alt={book.title}
                        className="w-full aspect-[2/3] object-cover rounded-t-lg"
                      />
                      <div className="p-3">
                        <h3 className="font-semibold text-sm text-gray-900 mb-1 line-clamp-2">
                          {book.title}
                        </h3>
                        <p className="text-xs text-gray-600 mb-2">{book.author}</p>
                        {book.rating && (
                          <div className="flex items-center gap-1">
                            <span className="text-yellow-500 text-xs">★</span>
                            <span className="text-xs font-semibold">{book.rating}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-12 sm:mt-16 md:mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <div className="text-center text-gray-600">
            <p className="font-semibold text-lg sm:text-xl mb-2" style={{background: 'linear-gradient(to left, #75420e, #553b08)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'}}>
              فهارس
            </p>
            <p className="text-xs sm:text-sm">مكتبة الكتب الإلكترونية العربية</p>
          </div>
        </div>
      </footer>
    </div>
  );
}