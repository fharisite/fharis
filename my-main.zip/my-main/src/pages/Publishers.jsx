import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building, BookOpen, Search, ArrowUpDown } from 'lucide-react';
import ModernHeader from '@/components/layout/ModernHeader';

export default function Publishers() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('books'); // books, name, followers

  const { data: publishers = [], isLoading: loadingPublishers } = useQuery({
    queryKey: ['publishers'],
    queryFn: () => base44.entities.Publisher.list(),
  });

  const { data: books = [], isLoading: loadingBooks } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
  });

  const { data: publisherFollows = [] } = useQuery({
    queryKey: ['publisherFollows'],
    queryFn: () => base44.entities.PublisherFollow.list(),
  });

  // Calculate book count and followers for each publisher
  const publishersWithStats = publishers.map(publisher => {
    const bookCount = books.filter(book => book.publisher_id === publisher.id).length;
    const followerCount = publisherFollows.filter(follow => follow.publisher_id === publisher.id).length;
    return {
      ...publisher,
      bookCount,
      followerCount
    };
  });

  // Filter and sort publishers
  const filteredPublishers = publishersWithStats
    .filter(publisher => 
      publisher.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      publisher.country?.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'books') {
        return b.bookCount - a.bookCount;
      } else if (sortBy === 'name') {
        return a.name.localeCompare(b.name, 'ar');
      } else if (sortBy === 'followers') {
        return b.followerCount - a.followerCount;
      }
      return 0;
    });

  const isLoading = loadingPublishers || loadingBooks;

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)'}} dir="rtl">
      <ModernHeader />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">دور النشر</h1>
          <p className="text-gray-600">استكشف دور النشر وإصداراتها</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)'}}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-white shadow-sm flex items-center justify-center">
                  <Building className="w-6 h-6" style={{color: '#75420e'}} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">إجمالي دور النشر</p>
                  <p className="text-2xl font-bold text-gray-900">{publishers.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-l from-blue-50 to-indigo-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-white shadow-sm flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">إجمالي الكتب</p>
                  <p className="text-2xl font-bold text-gray-900">{books.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-l from-green-50 to-emerald-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-white shadow-sm flex items-center justify-center">
                  <span className="text-2xl">👥</span>
                </div>
                <div>
                  <p className="text-sm text-gray-600">إجمالي المتابعات</p>
                  <p className="text-2xl font-bold text-gray-900">{publisherFollows.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Sort */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="ابحث عن دار نشر..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-48">
                  <ArrowUpDown className="w-4 h-4 ml-2" />
                  <SelectValue placeholder="ترتيب حسب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="books">عدد الكتب</SelectItem>
                  <SelectItem value="name">الاسم</SelectItem>
                  <SelectItem value="followers">عدد المتابعين</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Publishers Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3 mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredPublishers.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Building className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">لا توجد نتائج</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPublishers.map((publisher) => (
              <Link key={publisher.id} to={createPageUrl(`PublisherDetail?id=${publisher.id}`)}>
                <Card className="hover:shadow-xl transition-all hover:scale-105 cursor-pointer h-full">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      {publisher.logo ? (
                        <img 
                          src={publisher.logo} 
                          alt={publisher.name}
                          className="w-16 h-16 object-cover rounded-lg shadow"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-lg flex items-center justify-center shadow" style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)'}}>
                          <Building className="w-8 h-8" style={{color: '#75420e'}} />
                        </div>
                      )}
                      <div className="flex-1">
                        <h3 className="font-bold text-lg text-gray-900 mb-1">{publisher.name}</h3>
                        {publisher.country && (
                          <p className="text-sm text-gray-600">{publisher.country}</p>
                        )}
                      </div>
                    </div>

                    {publisher.description && (
                      <p className="text-sm text-gray-700 mb-4 line-clamp-2">
                        {publisher.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="flex items-center gap-2 text-sm">
                        <BookOpen className="w-4 h-4 text-blue-600" />
                        <span className="font-semibold">{publisher.bookCount}</span>
                        <span className="text-gray-600">كتاب</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-xl">👥</span>
                        <span className="font-semibold">{publisher.followerCount}</span>
                        <span className="text-gray-600">متابع</span>
                      </div>
                    </div>

                    {publisher.founded_year && (
                      <div className="mt-3 text-xs text-gray-500">
                        تأسست عام {publisher.founded_year}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}